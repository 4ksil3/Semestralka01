import java.util.ArrayList;

/**
 * Trieda SegPismeno vykresl� kl�vesnicu na pl�tno spolu s Displejmi.
 * Zis�uje na ak� p�smenko sa kliklo.
 */
public class SegPismeno {
    private Displej pismeno;

    private char[] znaky; 
    private ArrayList<Displej> pismena;
    private ArrayList<Stvorec> stvorce;
    private int suradnicaY;
    private int suradnicaX;
    private int suradnicePismenaX;
    private int suradnicePismenaY;
    private int pocitadlo;
    private int dlzkaSegmentu;
    private char zadanePismeno;

    private Hra hra;

    /**
     * Vytvor� pole abecedy a pod�a po�tu p�smen v poli znaky vytvor� �tvorce (�asti kl�vesnice),
     * pri�om pre ka�d� �tvorec vytvor� displej na vykreslenie p�smena.
     * Nastav� za�iato�n� s�radnice �tvorcov, za�iato�n� s�radnice displeja a d�ku displeja.
     */
    public SegPismeno(Hra hra) {
        this.znaky = new char[] {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'V', 'X', 'Y', 'Z'};
        this.stvorce = new ArrayList<Stvorec>();
        this.pismena = new ArrayList<Displej>();
        this.suradnicaX = 320;
        this.suradnicaY = 70;
        this.suradnicePismenaX = 390;
        this.suradnicePismenaY = 130;
        this.dlzkaSegmentu = 4;
        this.pocitadlo = 0;
        this.hra = hra;
        this.zadanePismeno = ' ';
        for (char aktualna:znaky) {
            this.stvorce.add(new Stvorec());
            if (pocitadlo == 8) {
                this.suradnicePismenaX = 365;
                this.suradnicePismenaY = 180;
            }
            if (pocitadlo == 17) {
                this.suradnicePismenaX = 410;
                this.suradnicePismenaY = 230;
            }

            this.pismena.add(new Displej(dlzkaSegmentu, suradnicePismenaX, suradnicePismenaY));
            this.suradnicePismenaX += 50;
            this.pocitadlo++;
        }
        this.pocitadlo = 0;
    }

    /**
     * Na kl�vesnici sa postupne vyp�u v�etky p�smen� z po�a znakov.
     */
    public void zobrazPismena() {
        for (Displej aktualna:pismena) {
            aktualna.zobraz(this.znaky[this.pocitadlo]);
            this.pocitadlo++;
        }
        this.pocitadlo = 0;
    }
    
    /**
     * Po kliknut� my�ou zist�me hodnoty x a y, na z�klade ktor�ch zis�ujeme, na ak� p�smenko hr�� klikol.
     */
    public char zistiPismenko() {
        int x = this.hra.getX();
        int y = this.hra.getY();
        int zacSurX = 380;
        int zacSurY = 120;

        for (int i = 0; i < this.znaky.length; i++) {
            if (( i <= 7 ) && ( x >= zacSurX ) && ( x <= zacSurX + 40) && ( y >= zacSurY) && ( y <= zacSurY + 40))  {
                this.zadanePismeno = this.znaky[i];
            }
            if ( i == 8) {
                zacSurX = 350;
                zacSurY = 170;
            }
            if (( i > 7) && ( i <= 16 ) && ( x >= zacSurX ) && ( x <= zacSurX + 40) && ( y >= zacSurY) && ( y <= zacSurY + 40)) {
                this.zadanePismeno = this.znaky[i];
            }
            if ( i == 17) {
                zacSurX = 400;
                zacSurY = 220;
            }
            if (( i > 16) && ( x >= zacSurX ) && ( x <= zacSurX + 40) && ( y >= zacSurY) && ( y <= zacSurY + 40)) {
                this.zadanePismeno = this.znaky[i];
            }
            zacSurX += 50;
        }
        return this.zadanePismeno;
    }

    /**
     * Met�da, ktor� vykresl� bielu "kl�vesnicu" na pl�tno.
     */
    public void zobrazStvorce() { 
        for (Stvorec test:stvorce) {
            if (pocitadlo == 8) {
                this.suradnicaX = 295;
                this.suradnicaY = 120;
            }
            if (pocitadlo == 17) {
                this.suradnicaX = 340;
                this.suradnicaY = 170;
            }
            test.zmenStranu(40);
            test.posunVodorovne(suradnicaX);
            test.posunZvisle(suradnicaY);
            test.zmenFarbu("white");
            test.zobraz();

            this.suradnicaX += 50;

            this.pocitadlo++;
        }
        this.pocitadlo = 0;
    }

}
