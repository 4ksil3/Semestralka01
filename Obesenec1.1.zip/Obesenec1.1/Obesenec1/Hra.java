
/**
 * Hlavn� trieda hry, ktor� sp�ja v�etky jej s��asti.
 */
public class Hra {
    private SegPismeno sA;
    private SpravneSlovo slovo;
    private int cislo;
    private char znak;
    private int x;
    private int y; 

    /**
     * Kon�truktor vytvor� z�kladn� �asti hry obesenec (kl�vesnicu, p�smenka na kl�vesnici, kon�trukciu
     * pre obesenca), do termin�lu vyp�e n�povedu h�dan�ho slova a pomocn� slovo.
     * Vytvor� in�tanciu mana��ra, ktor� bude spravova� hru.
     */
    public Hra() {
        System.out.print('\u000c'); 
        this.sA = new SegPismeno(this);
        this.sA.zobrazStvorce();
        this.sA.zobrazPismena();
        
        this.slovo = new SpravneSlovo();
        this.slovo.slova();
        this.slovo.vytvorPomocne();
        this.znak = ' ';
        
        new Manazer().spravujObjekt(this);
    }

    /**
     * Zist� s�radnice kliknutej s�radnice x a y.
     * S�radnice zap�e do atrib�tov.
     * Zist� pod�a s�radnice znak, na ktor� sa kliklo. 
     * Zavol� met�du zadajPismeno triedy SpravneSlovo.
     */
    public void vyberSuradnice(int x, int y) {
        if (!this.slovo.getHraSkoncila()) {
            this.x = x;
            this.y = y;
            this.znak = this.sA.zistiPismenko();
            this.slovo.zadajPismeno(this.znak);
        }
    }
    
    /**
     * Vr�ti hodnotu s�radnice x.
     * 
     * @return hodnota s�radnice x
     */
    public int getX() {
        return this.x;
    }
    
    /**
     * Vr�ti hodnotu s�radnice y.
     * 
     * @return hodnota s�radnice y
     */
    public int getY() {
        return this.y;
    }
    
    /**
     * Vypne hru po stla�en� kl�vesy Esc.
     */
    public void zrus() {
        System.exit(0);
    }

}
