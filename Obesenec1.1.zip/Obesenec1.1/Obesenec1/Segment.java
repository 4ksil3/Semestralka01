/**
 * Triedna na vytv�ranie segmentu.
 */
public class Segment {
    private int dlzkaSegmentu;
    private int poziciaX;
    private int poziciaY;
    private Stvorec segment;
    
    /**
     * Vytvor� 1 segment displeja skl�daj�ci sa zo �tvorca.
     * Nastav� mu po�iato�n� s�radnice x y.
     * Zmen� jeho ve�kos�.
     */
    public Segment(int dlzkaSegmentu, int poziciaX, int poziciaY) {
        this.dlzkaSegmentu = dlzkaSegmentu;
        this.poziciaX = poziciaX;
        this.poziciaY = poziciaY;
        this.segment = new Stvorec();
        this.segment.zmenFarbu("black");
        this.segment.posunVodorovne(poziciaX - 60);
        this.segment.posunZvisle(poziciaY - 50);
        this.segment.zmenStranu(dlzkaSegmentu);
    }
    
    /**
     * Zmen� farbu segmentu na �iernu.
     */
    public void rozsviet() {
        this.segment.zobraz();
        this.segment.zmenFarbu("black");
    }
    
    /**
     * Zmen� farbu segmentu na bielu.
     */
    public void zhasni() {
        this.segment.zmenFarbu("white");
    }
}

