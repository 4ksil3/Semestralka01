
/**
 * @author Eli�ka Z�vr�anova  
 * @version Obesenec1.1
 */
public class Aplikacia {
    public static void main(String[] ars) {
        Hra hra = new Hra();
    }
}
