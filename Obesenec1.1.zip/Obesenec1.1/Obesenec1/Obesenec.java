/**
 * Trieda Obesenec vykresluje jednotliv� �asti obesenca.
 */
public class Obesenec {
    private Kruh hlava;
    private Elipsa kamen1;
    private Elipsa kamen2;
    private Obdlznik rovina;
    private Obdlznik drevo1;
    private Obdlznik drevo2;
    private Obdlznik lano;
    private Obdlznik krk;
    private Elipsa telo;
    private Obdlznik ruka1;
    private Obdlznik ruka2;
    private Obdlznik noha1;
    private Obdlznik noha2;
    
    /**
     * Kon�truktor vytvor� �asti tela, ktor� sa bud� postupne zobrazova�
     * po ka�dom neuh�dnutom p�smenku.
     */
    public Obesenec() {
        this.hlava = new Kruh();
        this.kamen1 = new Elipsa();
        this.kamen2 = new Elipsa();
        this.rovina = new Obdlznik();
        this.drevo1 = new Obdlznik();
        this.drevo2 = new Obdlznik();
        this.lano = new Obdlznik();
        this.krk = new Obdlznik();
        this.telo = new Elipsa();
        this.ruka1 = new Obdlznik();
        this.ruka2 = new Obdlznik();
        this.noha1 = new Obdlznik();
        this.noha2 = new Obdlznik();
    }
    /**
     * Met�d zobrazKonstrukciu() zobraz� z�kladn� �asti kon�trukcie pri spusten� hry.
     */
    public void zobrazKonstrukciu() {
        this.kamen1.zmenOsi(110, 90);
        this.kamen2.zmenOsi(60, 80);
        this.rovina.zmenStrany(250, 70);
        this.kamen1.zmenFarbu("white");
        this.kamen2.zmenFarbu("white");
        this.rovina.zmenFarbu("yellow");
        this.kamen1.posunVodorovne(30);
        this.kamen1.posunZvisle(190);
        this.kamen2.posunZvisle(200);
        this.kamen2.posunVodorovne(12);
        this.rovina.posunZvisle(250);
        this.rovina.posunVodorovne(-40);
        this.drevo1.zmenStrany(10, 150);
        this.drevo1.zmenFarbu("white");
        this.drevo1.posunVodorovne(42);
        this.drevo1.posunZvisle(71);
        this.drevo2.zmenStrany(115, 10);
        this.drevo2.zmenFarbu("white");
        this.drevo2.posunVodorovne(42);
        this.drevo2.posunZvisle(61);
        this.kamen1.zobraz();
        this.kamen2.zobraz();
        this.rovina.zobraz();
        this.drevo1.zobraz();
        this.drevo2.zobraz();
    }
    
    /**
     * Met�da zobrazLano() zobraz� lano - prv� �as� obesenca
     * pri prvom neuh�dnutom p�smenku.
     */
    public void zobrazLano() {
        this.lano.zmenFarbu("white");
        this.lano.zmenStrany(4, 30);
        this.lano.posunVodorovne(140);
        this.lano.posunZvisle(62);
        this.lano.zobraz();
    }
    
    /**
     * Met�da zobrazKlavu() zobraz� klavu - druh� �as� obesenca
     * pri druhom neuh�dnutom p�smenku.
     */
    public void zobrazHlavu() {
        this.hlava.zmenPriemer(30);
        this.hlava.posunVodorovne(166);
        this.hlava.posunZvisle(80);
        this.hlava.zmenFarbu("white");
        this.hlava.zobraz();
    }
    
    /**
     * Met�da zobrazKrk() zobraz� krk - tretiu �as� obesenca 
     * pri tre�om neuh�dnutom p�smenku.
     */
    public void zobrazKrk() {
        this.krk.zmenFarbu("white");
        this.krk.zmenStrany(5, 20);
        this.krk.posunVodorovne(140);
        this.krk.posunZvisle(110);
        this.krk.zobraz();
    }
    
    /**
     * Met�da zobrazTelo() zobraz� telo - �tvrt� �as� obesenca
     * pri �tvrtom neuh�dnutom p�smenku.
     */
    public void zobrazTelo() {
        this.telo.zmenFarbu("white");
        this.telo.posunVodorovne(167);
        this.telo.posunZvisle(117);
        this.telo.zmenOsi(30, 55);
        this.telo.zobraz();
    }
    
    /**
     * Met�da zobrazRuku1() zobraz� prav� ruku - piatu �as� obesenca 
     * pri piatom neuh�dnutom p�smenku.
     */
    public void zobrazRuku1() {
        this.ruka1.zmenFarbu("white");
        this.ruka1.zmenStrany(25, 5);
        this.ruka1.posunVodorovne(117);
        this.ruka1.posunZvisle(130);
        this.ruka1.zobraz();
    }
      
    /**
     * Met�da zobrazRuku2() zobraz� �av� ruku - �iestu �as� obesenca 
     * pri �iestom neuh�dnutom p�smenku.
     */
    public void zobrazRuku2() {
        this.ruka2.zmenFarbu("white");
        this.ruka2.zmenStrany(25, 5);
        this.ruka2.posunVodorovne(143);
        this.ruka2.posunZvisle(130);
        this.ruka2.zobraz();
    }
    
    /**
     * Met�da zobrazNohu1() zobraz� prav� nohu - siedmu �as� obesenca
     * pri siedmom neuh�dnutom p�smenku.
     */
    public void zobrazNohu1() {
        this.noha1.zmenFarbu("white");
        this.noha1.zmenStrany(5, 30);
        this.noha1.posunVodorovne(134);
        this.noha1.posunZvisle(178);
        this.noha1.zobraz();
    }
    
    /**
     * Met�da zobrazNohu2() zobraz� �av� nohu - �smu �as� obesenca
     * pri �smom neuh�dnutom p�smenku.
     */
    public void zobrazNohu2() {
        this.noha2.zmenFarbu("white");
        this.noha2.zmenStrany(5, 30);
        this.noha2.posunVodorovne(146);
        this.noha2.posunZvisle(178);
        this.noha2.zobraz();
    }
}
