import java.util.Stack;

/**
 * Trieda SpravneSlovo zist�, ktor� slovo sa bude h�da�, vytvor� si pomocn� slovo a pod�a kliknut�ho p�smenka
 * rozhodne �i sa v slove nach�dza alebo nie.
 */
public class SpravneSlovo {
    private Napovedy zoznam;
    private int cislo;
    private String hadaneSlovo;
    private String pomocneSlovo;
    private char[] hs;
    private char[] ps;
    private int pocetNespravnych;
    private boolean nachadzaSa;
    private boolean hraSkoncila;
    private Stack<Character> znakyKliknute;
    private Obesenec obesenec;
    
    /**
     * Kon�truktor nastav� za�iato�n� hodnoty h�dan�ho a pomocn�ho slova,
     * vytvor� referenciu triedy Stuck do ktorej bude uklada� pou�it� slov�.
     */
    public SpravneSlovo() {
        this.hadaneSlovo = "";
        this.hs = this.hadaneSlovo.toCharArray();
        
        this.pomocneSlovo = "";
        this.ps = this.pomocneSlovo.toCharArray();
        
        this.pocetNespravnych = 0;
        this.nachadzaSa = false;
        this.znakyKliknute = new Stack<Character>();
        this.zoznam = new Napovedy();
        this.cislo = this.zoznam.getCislo();
        
        this.hraSkoncila = false;

        this.obesenec = new Obesenec();
        this.obesenec.zobrazKonstrukciu();
    }
    
    /**
     * Pod�a ��sla h�danej ot�zky sa do atrib�tu hadaneSlovo ulo�� slovo, ktor� bude hr�� h�da�.
     * 
     * @param cislo poradov� ��slo h�dan�ho slova 
     */
    public void slova() { 
        this.zoznam.napovede(this.cislo);
        switch (this.cislo) {
            case 1:
                this.hadaneSlovo = "LISABON";
                break;
            case 2:
                this.hadaneSlovo = "EDISON";
                break;
            case 3:
                this.hadaneSlovo = "KVADRAT";
                break;
            case 4: 
                this.hadaneSlovo = "UHLIK";
                break;
            case 5:
                this.hadaneSlovo = "ZLATO";
                break;
            case 6:
                this.hadaneSlovo = "NETOPIER";
                break;
        }
    }
    
    /**
     * Vytvor� sa pomocn� slovo, do ktor�ho sa budu na spr�vne poz�cie zapisova� p�smenk�, ktor� zadal hr��.
     * Pomocn� slovo sa rozdel� na pole znakov.
     */
    public void vytvorPomocne() {
        this.hs = this.hadaneSlovo.toCharArray();
        for (int j = 0; j < hs.length; j++) {
            this.pomocneSlovo = pomocneSlovo + "*";
        }
        System.out.print(this.pomocneSlovo);
        this.ps = this.pomocneSlovo.toCharArray();
    }
    
    /**
     * Po kliknut� na p�smenko na "kl�vesnici" zist� �i sa p�smeno v h�danom slove nach�dza.
     * Ak sa p�smeno nach�dza v slove a nenach�dza sa u� v kliknut�ch slov�ch, vyp�e sa do pomocn�ho slova.
     * Ak sa p�smeno nenach�dza v slove a nebolo e�te kliknut�, zv��i sa po�et nespr�vnych p�smen.
     * Pod�a po�tu nespr�vnych p�smen sa zobrazuj� �asti tela obesenca.
     * V pr�pade, �e sme uh�dli slovo sk�r, ako sa objavili v�etky �asti tela obesenca, hra skon�ila a hr�� vyhral.
     * V pr�pade, �e h�dan� slovo sa neuh�dlo na po�et �ast� obesenca, hra skon�ila a hr�� prehral.
     */
    public void zadajPismeno(char znak) {
        if (!this.hraSkoncila) {
            this.nachadzaSa = false;
            for (int i = 0; i < hs.length; i++) {
                if (hs[i] == (znak) && !this.znakyKliknute.contains(znak)) {
                    ps[i] = znak ;
                    this.nachadzaSa = true;
                    
                }
            }
            
            if (nachadzaSa) {
                System.out.println();
                for (int j = 0; j < hs.length; j++) {
                    System.out.print(ps[j]);
                }
            }
            int pocet = 0;
            for (int o = 0; o < hs.length; o++) {
                if (hs[o] == ps[o]) {
                    pocet++;
                    if (pocet == hs.length) {
                        this.hraSkoncila = true;
                        System.out.print('\u000c');
                        System.out.println("  Vyhral si !!! ");
                        System.out.println(" hadane slovo bolo: " + this.hadaneSlovo);
                        Stvorec koniec = new Stvorec();
                        koniec.zmenFarbu("yellow");
                        koniec.zmenStranu(600);
                        koniec.posunVodorovne(280);
                        koniec.posunZvisle(-100);
                        koniec.zobraz();
                    }
                }
            }

            if (!nachadzaSa && !this.znakyKliknute.contains(znak)) {
                this.pocetNespravnych++;
                switch (pocetNespravnych) {
                    case 1:
                        this.obesenec.zobrazLano();
                        break;
                    case 2:
                        this.obesenec.zobrazHlavu();
                        break;
                    case 3:
                        this.obesenec.zobrazKrk();
                        break;
                    case 4:
                        this.obesenec.zobrazTelo();
                        break;
                    case 5:
                        this.obesenec.zobrazRuku1();
                        break;
                    case 6:
                        this.obesenec.zobrazRuku2();
                        break;
                    case 7:
                        this.obesenec.zobrazNohu1();
                        break;
                    case 8:
                        this.obesenec.zobrazNohu2();
                        break;
                }
            }

            this.znakyKliknute.add(znak);

            if (pocetNespravnych == 8) {
                this.hraSkoncila = true;
                System.out.print('\u000c');
                System.out.println("HRA SKONCILA");
                System.out.println(" PREHRAL SI!!!");
                System.out.println(" hadane slovo bolo: " + this.hadaneSlovo);
                Stvorec koniec = new Stvorec();
                koniec.zmenFarbu("yellow");
                koniec.zmenStranu(600);
                koniec.posunVodorovne(280);
                koniec.posunZvisle(-100);
                koniec.zobraz();
            } 
        } 
    }
    
    /**
     * Vr�ti hodnotu, ktor� hovor� �i hra skon�ila alebo nie.
     * False : hra neskon�ila.
     * True : hra skon�ila.
     * 
     * @return vr�ti sa stav hry (skon�ila/neskon�ila)
     */
    public boolean getHraSkoncila() {
        return this.hraSkoncila;
    }
}
