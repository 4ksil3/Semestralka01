import java.util.Random;
/**
 * Trieda Napoveda vyberie n�povedu h�dan�ho slova pod�a n�hodne vygenerovan�o ��sla.
 */
public class Napovedy {
    private int cisloOtazky;

    /**
     * Kon�truktor vygeneruje n�hodn� ��slo (��slo h�danej ot�zky) od <1,6>. 
     * N�hodn� ��slo ur�uje, ktor� slovo sa bude h�da�.
     */
    public Napovedy() {
        Random cislo = new Random();
        this.cisloOtazky = cislo.nextInt(6) + 1;
    }

    /**
     * Vr�ti ��slo h�danej ot�zky. 
     * 
     * @return ��slo ot�zky
     */
    public int getCislo() {
        return this.cisloOtazky;
    }

    /**
     * Pod�a ��sla h�danej ot�zky vyp�e n�povedu slova, ktor� bude hr�� h�da�.
     * 
     * @param cisloOtazky poradov� ��slo n�povedy
     */
    public void napovede(int cisloOtazky) {
        switch (cisloOtazky) {
            case 1:
                System.out.println("Hlavn� mesto Portugalska");
                break;
            case 2:
                System.out.println("Vyn�lezca �iarovky");
                break;
            case 3:
                System.out.println("Druh� mocnina ��sla");
                break;
            case 4:
                System.out.println("Chemick� prvok : C ");
                break;
            case 5:
                System.out.println("Chemick� prvok : Au ");
                break;
            case 6:
                System.out.println("Naj�ah�� cicavec");
                break;
        }

    }
}
